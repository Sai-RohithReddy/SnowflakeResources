CREATE OR REPLACE DATABASE mydb;

-- Q4
CREATE OR REPLACE TABLE t1 (ID int);
CREATE OR REPLACE TABLE t2 (ID int);

INSERT INTO t1 VALUES (1), (4), (6), (8), (9), (null);
INSERT INTO t2 VALUES (1), (7), (3), (null);

SELECT * FROM t1;
SELECT * FROM t2;

SELECT a.ID, b.ID FROM t1 AS a INNER JOIN t2 AS b on a.ID = b.ID;
SELECT COUNT(*) FROM t1 INNER JOIN t2 ON t1.ID = t2.ID;

SELECT a.ID, b.ID FROM t1 AS a LEFT OUTER JOIN t2 AS b on a.ID = b.ID;
SELECT COUNT(*) FROM t1 LEFT OUTER JOIN t2 ON t1.ID = t2.ID;

SELECT a.ID, b.ID FROM t1 AS a RIGHT OUTER JOIN t2 AS b on a.ID = b.ID;
SELECT COUNT(*) FROM t1 RIGHT OUTER JOIN t2 ON t1.ID = t2.ID;

SELECT a.ID, b.ID FROM t1 AS a FULL JOIN t2 AS b on a.ID = b.ID;
SELECT COUNT(*) FROM t1 FULL JOIN t2 ON t1.ID = t2.ID;

-- Q3
CREATE OR REPLACE TABLE input_table (City varchar, Year int, Amount int);
INSERT INTO input_table VALUES ('Mumbai', 2018, 3672), ('Mumbai', 2019, 8745), ('Mumbai', 2020, 10987), ('Pune', 2020, 2367),('Pune', 2021, 4532),('Pune', 2022, 6798), ('Bangalore', 2019, 5634), ('Bangalore', 2020, 4754), ('Bangalore', 2021, 7368);

SELECT * FROM input_table;


SELECT City, Year, Amount, SUM(Amount) OVER (PARTITION BY City ORDER BY Year) AS "Running Total" FROM input_table 
ORDER BY CITY, Year;

-- Q2
SELECT * FROM input_table
PIVOT (MAX(AMOUNT) FOR Year IN (2018, 2019, 2020, 2021, 2022));

-- Q1
CREATE OR REPLACE TABLE emp_table (ID INT, Name VARCHAR, Location VARCHAR);

INSERT INTO emp_table VALUES (1, 'monish', 'Mumbai'), (1, 'monish', 'Delhi'), (2, 'Saumya', 'Mumbai'), (2, 'Saumya', 'Hyderabad'), (3, 'ABC', 'Mumbai'), (4, 'DEF', 'Delhi');

SELECT * from emp_table;

SELECT * FROM emp_table e1 JOIN emp_table e2 ON e1.id = e2.id WHERE e1.location = 'Mumbai' AND e2.location = 'Delhi';
SELECT id FROM emp_table WHERE location IN ('Mumbai', 'Delhi') GROUP BY id HAVING COUNT(DISTINCT location) = 2;

INSERT INTO emp_table VALUES (4, 'DEF', 'Mumbai');

SELECT e1.id, e1.name FROM emp_table e1 JOIN emp_table e2 ON e1.id = e2.id WHERE e1.location = 'Mumbai' AND e2.location = 'Delhi';



-- CREATE OR REPLACE TABLE MYDB.PUBLIC.ORDERS_NONCLUSTER
-- AS SELECT * FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF100.ORDERS;

CREATE OR REPLACE TABLE MYDB.PUBLIC.ORDERS_CLUSTER
AS SELECT * FROM SNOWFLAKE_SAMPLE_DATA.TPCH_SF100.ORDERS;

ALTER TABLE ORDERS_CLUSTER CLUSTER BY(YEAR(O_ORDERDATE));

SELECT SYSTEM$CLUSTERING_INFORMATION('ORDERS_CLUSTER');
SELECT SYSTEM$CLUSTERING_INFORMATION('ORDERS_NONCLUSTER');

ALTER TABLE ORDERS_CLUSTER RECLUSTER;

SELECT * FROM input_table;


SELECT * FROM input_table
PIVOT (SUM(amount) FOR YEAR IN (2018, 2019, 2020, 2021, 2022));

SELECT * FROM input_table
UNPIVOT (amount FOR YEAR IN (2018, 2019, 2020, 2021, 2022));